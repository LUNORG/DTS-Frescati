# To do list:

* [ ] Decide what to buy
* [ ] Get the hardware (RevPi and Lucid Control)
* [ ] Map the ins and outs
* [ ] Replace the plc
* [ ] Implementing the different functionalities
  * [ ] Main loop & architecture (see Thierry's work)
  * [ ] RevPi modules
  * [ ] ModBus (Thermia Heat Pump)
  * [ ] LucidIO module (RTD)
  * [ ] PIDs & control (control modes?)
    * [ ] Flow
    * [ ] Heat
  * [ ] GUI?
* [ ] Power meter?
* [ ] Pressure drop meter?
* [ ] Putting it together



# Current plan for architecture

- main loop with (
