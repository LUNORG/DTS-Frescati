using Dates
using DataFrames
using Plots
using Dierckx
using LinearAlgebra
using Statistics
using Parquet
using Pkg
using LibPQ
Pkg.instantiate()

conn = LibPQ.Connection("host=bdgeogis.postgres.database.azure.com dbname=kth_optimal_flow user=BengtDahlgren password=BDAB20_21!")

# Define the SQL query
query = """ 
    SELECT timestamp, length, temperature
    FROM frescati_data
    WHERE channel = 1
      AND timestamp >= '2019-05-01'
      AND timestamp < '2019-06-01'
"""

# Execute the query and get the result into a DataFrame
df = DataFrame(LibPQ.execute(conn, query))

# Write the DataFrame to a Parquet file
Parquet.write_parquet("local_db.parquet", df)

#LN: load data back into the df data format:
df = DataFrame(Parquet.read_parquet("local_db.parquet"))


print(df[1:100,1])
print(df[end-100:end,1])
#LN: converts time-unit to unix time in order to be able to sort by timestamp:
df.timestamp = unix2datetime.(df.timestamp)
#LN: Sort the DataFrame by :timestamp (ascending order of rows)
#df_sorted = sort(df_local, :timestamp)
df_sorted = sort(df, :timestamp)

#LN: 'combine = first' makes it so the duplicate values are ignored, and that we only take the first instance of each duplicate 
udf = unstack(df_sorted, :timestamp, :length, :temperature, combine = first)
#LN: removes the repetition in df since it has many iterations of each length within (becuase of channel and time)
#LN: sorts df.length by size whilst removing duplicate values within.
lengths_vector = df.length |> unique |> sort  #LN: same as: lengths_vector = sort(unique(df.length))
                                                 # Which becomes a vector for all the length values.
times_vector = udf.timestamp #LN: a vector containing all time values.


mat_T = Matrix(udf[:,2:end]) #LN: 'Wide' matrix for all temperatures; excluding the first column since the first column are all thge timestamps.
plotly()

#LN: Makes a heat map y-axis:Time, x-axis:Length, all values in between come from mat_T (all temperatures):
Heatmap_mat_T = heatmap(lengths_vector, times_vector, mat_T)
#LN: surface(lengths_vector, times_vector, mat_T, size=(800,600))
#LN: plots lengths by the first time in mat_T:
time0_plot= plot(lengths_vector, mat_T[1,:], xlabel="distance (m)", ylabel="Temperature (m)")
#LN: plots time by the first sensor (first point of measurement along the fiber) in mat_T:
length0_plot = plot(times_vector, mat_T[:,500], xlabel="Time", ylabel="Temperature (m)")

#LN: Averages the rows in a matrix, converting it to a [1xn]-format:
function avg_rows(matrix)
    return mean(matrix, dims=1)
end

vec_T_average_temp = vec(avg_rows(mat_T)) #LN: now a [1xn] matrix (vector) where length(n) = length(length_vector) and the row is the averaged temperatures
scatterplot_avg_T = scatter(lengths_vector, vec_T_average_temp) #LN: Plots an averaged temperture by length plot

#LN: Using the scatterplot to visually ID the bounds of a bh, now we want to find the indexes that correspond to these bounds in meters:
start_bh_n = 1520 #LN: The actual length (m) along the DTS where the bh starts (visual measurement of scatterplot_avg_T)
end_bh_n = 1971 #LN: same as ^ but end of bh

#LN: Anonymous function for finding the first index in lengths_vector after the visaully measured bh start:
length_start_bh_n = findfirst(x -> x >= start_bh_n, lengths_vector)
#LN: Anonymous function for finding the first index in lengths_vector after the visaully measured bh end:
length_end_bh_n = findlast(x -> x <= end_bh_n, lengths_vector)

bh_n_T = mat_T[:,length_start_bh_n:1:length_end_bh_n] #LN: The heat matrix for bh_n 
length_bhn = lengths_vector[length_start_bh_n:1:length_end_bh_n] #LN: length start and end of bh_n

heatmap_bh_n = heatmap(times_vector, length_bhn, bh_n_T') #LN: heatmap for the dts-sensors withing bh_n
disp(scatterplot_avg_T)
disp(time0_plot)
disp(length0_plot)
disp(heatmap_bh_n)

plotly()
#heatmap(lengths_vector, times_vector, mat_T)
#surface(lengths_vector, times_vector, mat_T, size=(800,600))
# Function to find rows with missing or NaN values
#LN: below shouldnt be used.
                        function find_and_remove_missing!(df::DataFrame, datetime_col::Symbol)
                            missing_rows = []
                            
                            for row in eachrow(df)
                                if any(x -> ismissing(x) || (x isa AbstractFloat && isnan(x)), row)
                                    push!(missing_rows, row[datetime_col])
                                end
                            end

                            println("Datetime values with missing data: ", missing_rows)

                            # Remove rows with missing values
                            filter!(row -> !(row[datetime_col] in missing_rows), df)
                        end
                        find_and_remove_missing!(udf, :timestamp)

# Extract the sorted matrix (excluding the first column which corresponds to the datetime)
#LN: Not needed:    udf = udf[!, 2:end]
#LN: Not needed:    sorted_columns = sort(parse.(Float64, names(udf)))
#LN: Not needed:    udf_sorted = udf[:, Symbol.(string.(sorted_columns))]
#LN: Not needed:    # Convert the sorted DataFrame to a matrix
#LN: Not needed:    M_T = Array(udf_sorted)

default(show = true)  # Forces plots to pop up in a new window


filepath_channel1 = "C:\\Users\\matil\\OneDrive\\Documenti\\UNIBO\\master_thesis_KTH\\pyenv\\correct_variance_dict_channel1.json"
filepath_channel2 = "C:\\Users\\zezro\\Documents\\GitHub\\lil-test-rig-control\\DTS\\uncertanty_evaluation\\variance_dict_channel2.json"
#LN: ^Filepath my laptop
# Load the correct JSON file into a Julia dictionary
complete_variance_dict = JSON.parsefile(filepath_channel2)
variance_dict = Dict(k => v for (k, v) in complete_variance_dict if parse(Float64, k) > 0.0)
variance_sorted = string.(sort(parse.(Float64, k for k in keys(variance_dict))))

# Replace missing with NaN
temperature_matrix = coalesce.(mat_T, NaN)

σ² = collect(variance_dict[i] for i in variance_sorted) # Variances stored in the dictionary
R = σ²

function extend_variance(R_column, n_rows)
    # Replicate the column variances across all rows
    return repeat(R_column', n_rows, 1)
end

n_rows, n_columns = size(temperature_matrix)
# Extend the column variances across rows
measurement_noise = extend_variance(R, n_rows)

function kalman_filter(data, process_noise, measurement_noise, A) #IF: A = avvikelse skalär
    n_rows, n_columns = size(data) #IF:rows and columns in data. 
    filtered_data = similar(data) #IF: matex to store similar results

    # Initialize state estimates and covariances for all columns 
    x_est = zeros(n_columns)
    P_est = ones(n_columns)

    for t in 1:n_rows
        for j in 1:n_columns
            # Predict Step: Includes trend adjustment
            x_pred = A * x_est[j]
            P_pred = A * P_est[j] * A + process_noise

            # Calculate Kalman Gain
            K = P_pred / (P_pred + measurement_noise[t, j])

            # Update Step
            x_est[j] = x_pred + K * (data[t, j] - x_pred)
            P_est[j] = (1 - K) * P_pred

            # Save the updated value back to the matrix
            filtered_data[t, j] = x_est[j]
        end
    end
    return filtered_data
end

# Define parameters
A = 1.00                         # Slight upward trend
process_noise = 1e-2             # Small process noise for stable data
measurement_noise = fill(length(data))
temperature_matrix = 

# Apply the Kalman filter
Kalman_matrix = kalman_filter(temperature_matrix, process_noise, measurement_noise, A)

#------ Spline interpolation
fiber_lengths = sort(unique(df.length))
fiber_lenghts = coalesce.(fiber_lengths, NaN)
datetimes_values = unique(udf.datetime)
datetimes_values = collect(skipmissing(datetimes_values))
reference = datetimes_values[1]
datetimes_seconds = Millisecond.(datetimes_values .- reference)
time_values = [datetimes_seconds[i].value /1000 for i in 1:length(datetimes_seconds)]
# time_values[2:end].-time_values[1:end-1]|>unique
full_time_values = collect(0:600:time_values[end])

function find_constant_intervals(time_values::Vector{Float64}, expected_diff::Float64)
    intervals = []  # To store the (t1, t2) intervals
    n = length(time_values)

    start_index = 1  # Start of the current interval

    while start_index < n
        end_index = start_index

        # Extend the interval as long as the condition holds
        while end_index < n && time_values[end_index + 1] - time_values[end_index] < expected_diff
            end_index += 1
        end

        # If the interval has more than one valid time step, record it
        if end_index > start_index
            push!(intervals, (time_values[start_index], time_values[end_index]))
        end

        # Move to the next possible start
        start_index = end_index + 1
    end

    return intervals
end
boundaries = find_constant_intervals(time_values, 700.0)

function valid_times(time::Float64, intervals::Vector{Any})
    for i in 1:length(intervals)
        if (intervals[i][1]) <= time <= (intervals[i][2])
            return 1  # Return 1 if time is within any interval
        end
    end
    return NaN  # Return NaN if time does not match any interval
end

function valid_times(time::Vector{Float64}, intervals::Vector{Any})
    return map(t -> valid_times(t, intervals), time)
end

# Do not use k<3 otherwise the interpolation between the missing time data is very wrong
spline_2d_50000 = Spline2D(time_values, fiber_lengths, Kalman_matrix, kx=3, ky=3, s=400000) 
z_values = [spline_2d_20000(x, y)*valid_times(x, boundaries) for x in full_time_values, y in fiber_lengths]  

# trying with different values of s to estimate the best in term of smoothness and accuracy
spline_2d_25000 = Spline2D(time_values, fiber_lengths, Kalman_matrix, kx=3, ky=3, s=500000) 
spline_2d_20000 = Spline2D(time_values, fiber_lengths, Kalman_matrix, kx=3, ky=3, s=600000) 

plotly()
plot(t->spline_2d_50000(t, fiber_lenghts[50]), 0, time_values[end])
plot!(t->spline_2d_25000(t, fiber_lenghts[50]), 0, time_values[end])
plot!(t->spline_2d_20000(t, fiber_lenghts[50]), 0, time_values[end])
# raw data downsampled
scatter!(time_values, Kalman_matrix[:,50])

# now the time dimension 
plot(x->spline_2d_30000(time_values[4020], x), fiber_lenghts[1], fiber_lenghts[end])
plot!(x->spline_2d_5000(time_values[4020], x), fiber_lenghts[1], fiber_lengths[end])
plot!(x->spline_2d_2000(time_values[4020], x), fiber_lenghts[1], fiber_lenghts[end])
# raw data downsampled
scatter!(fiber_lengths, Kalman_matrix[4020,:])

mean_absolute_error, max_absolute_error = compute_error_metrics(Kalman_matrix, time_values, fiber_lengths, spline_2d_20000)

#------------- Plotting
# For channel2 we start at length = 58 --> fiber_lengths[30] and stop at 407.919m --> fiber_lenghts[202=end-2]
# For channel 1 we start at length = 54 --> fiber_lengths[8] and stop at 154.271 --> fiber_lenghts[57=end-2] 

# Number of desired ticks
num_ticks = 8
# Generate evenly spaced indices for the ticks
tick_indices = round.(Int, LinRange(1, length(full_time_values), num_ticks))
selected_ticks = full_time_values[tick_indices]
selected_labels = [string(Date(reference + Second(val))) for val in selected_ticks]
# Generate the plot with reduced xticks
# Create a 3D surface plot
surfacepl = surface(full_time_values[1:50:end], fiber_lenghts[30:end-2], z_values[1:50:end,30:end-2]', 
    ylabel="Fiber Lengths", xlabel="Time", zlabel="Temperature",
    title="Surface Plot of Temperature Spline Function", legend=false,
    xticks=(selected_ticks, selected_labels), size=(800,600)    
)
savefig(surfacepl, "surface_channel2_2024.html")

contourpl = contourf(full_time_values[1:50:end], fiber_lenghts[30:end-2], z_values[1:50:end,30:end-2]', 
    ylabel="Fiber Lengths", xlabel="Time", zlabel="Temperature",
    title="Contour Plot of Temperature Spline Function", legend=true,  color=:thermal,
    xticks=(selected_ticks, selected_labels), # Reduced tick positions and labels
    size=(800,600)
)
savefig(contourpl, "contour_channel2_2024.html")

heatmappl = heatmap(full_time_values[1:50:end], fiber_lenghts[30:end-2], z_values[1:50:end, 30:end-2]', 
    ylabel="Fiber Lengths", xlabel="Time", zlabel="Temperature",
    title="Heatmap of Temperature Spline Function", legend=true,
    xticks=(selected_ticks, selected_labels), # Reduced tick positions and labels
    size = (800,600)
)
savefig(heatmappl, "heatmap_channel2_2024.html")

#-------------ERROR EVALUATION --------------------
# Function to compute general error metrics
function compute_error_metrics(matrix, time_values, fiber_lengths, spline2d)
    n_rows, n_cols = size(matrix)
    max_absolute_error = 0.0
    residual_total = 0.0

    for i in 1:n_rows
        for j in 1:n_cols
            # Map the matrix indices to the corresponding fiber length and time values
            y = fiber_lengths[j]
            x = time_values[i]
            
            # Evaluate the spline function at (x, y)
            predicted = spline2d(x, y)
            
            # Compute residual (signed difference)
            residual = matrix[i, j] - predicted
            residual_total += abs(residual)   # Sum of residuals to calculate mean error
           
            # Compute absolute error
            absolute_error = abs(residual)
            if absolute_error > max_absolute_error
                max_absolute_error = absolute_error  # Track maximum absolute error
            end
        end
    end
    num_elements = n_rows * n_cols 
    mean_abs_error = residual_total / num_elements  # Mean error across all elements

    return mean_abs_error, max_absolute_error
end

mean_absolute_error, max_absolute_error = compute_error_metrics(Kalman_matrix, time_values, fiber_lengths, spline_2d_20000)
errors = Dict(
    "mean_absolute_error" => mean_absolute_error,
    "residuals_sum" => spline_2d_20000.fp,
    "max_absolute_error" => max_absolute_error
)

# Save errors to a JSON file
open("errors_channel2_2024.json", "w") do io
    JSON.print(io, errors)
end

#------------- T-Tave 
# Compute the mean for each column
average_T = mean(z_values[:,32:end-2], dims=2)
# Create the modified matrix with T - average_T
matrix_diff = z_values[:,32:end-2] .- average_T

# Plot the contour
contourplot = contourf(full_time_values[1:50:end], fiber_lenghts[32:end-2], matrix_diff[1:50:end,:]', 
    ylabel="Fiber Lengths", xlabel="Time", zlabel="Temperature", clims=(-2.5, 2.5),
    title="Contour Plot of Temperature Spline Function", legend=true,  color=:thermal,
    xticks=(selected_ticks, selected_labels) # Reduced tick positions and labels
)
savefig(contourplot, "TempDepthShift_channel2_2024.html")

#----------- Matrix of temperature derivative over time
time_derivative_matrix = derivative(spline_2d_20000, time_values, fiber_lengths, 1, 0)
time_derivative_df = DataFrame(time_derivative_matrix, :auto)
# Save the DataFrame to a CSV file
CSV.write("channel2_2024_derivative_matrix.csv", time_derivative_df)

#-----------------MONTH PER MONTH------------------
function process_monthly_data(df_sorted::DataFrame, fiber_lengths::Vector{Union{Missing, Float64}}, process_noise::Float64, measurement_noise::Matrix{Float64}, A::Float64, smoothness::Int64)
    # Month name mapping
    month_names = Dict(1 => "jan", 2 => "feb", 3 => "mar", 4 => "apr", 5 => "may", 6 => "jun", 
                       7 => "jul", 8 => "aug", 9 => "sep", 10 => "oct", 11 => "nov", 12 => "dec")

    # Ensure datetime column is of type DateTime
    df_sorted.datetime = DateTime.(df_sorted.datetime)
    months = unique(month.(df_sorted.datetime))

    for i in 1:length(months)
        month_name = month_names[months[i]]  # Get the month name
        println("Processing data for month: ", month_name)

        # Filter the DataFrame for the current month
        monthly_df = filter(row -> month(row.datetime) == months[i], df_sorted)

        # Unstack the DataFrame to get the matrix form
        monthly_udf = unstack(monthly_df, :timestamp, :length, :temperature)
        find_and_remove_missing!(monthly_udf, :timestamp)

        # Extract the sorted matrix (excluding datetime column)
        monthly_data = monthly_udf[!, 2:end]
        monthly_columns = sort(parse.(Float64, names(monthly_data)))
        monthly_data_sorted = monthly_data[:, Symbol.(string.(monthly_columns))]

        # Convert the DataFrame to a matrix
        monthly_matrix = Array(monthly_data_sorted)
        monthly_matrix = coalesce.(monthly_matrix, NaN)

        # Apply Kalman filtering column-wise
        smooth_matrix = kalman_filter(monthly_matrix, process_noise, measurement_noise, A)

        # Spline interpolation
        unique_dates = unique(monthly_udf.datetime)
        unique_dates = collect(skipmissing(unique_dates))

        ref_date = unique_dates[1]
        date_diffs = Millisecond.(unique_dates .- ref_date)
        time_values = [date_diffs[i].value / 1000 for i in 1:length(date_diffs)]
        full_time_values = collect(0:600:time_values[end])

        num_ticks = 8
        # Generate evenly spaced indices for the ticks
        tick_indices = round.(Int, LinRange(1, length(full_time_values), num_ticks))
        selected_ticks = full_time_values[tick_indices]
        selected_labels = [string(Date(ref_date + Second(val))) for val in selected_ticks]        
        intervals = find_constant_intervals(time_values, 700.0)

        spline_2d = Spline2D(time_values, fiber_lengths, smooth_matrix, kx=3, ky=3, s=smoothness)
        z_values = [spline_2d(x, y)*valid_times(x, intervals) for x in full_time_values, y in fiber_lengths]  

        surfacepl = surface(full_time_values[1:5:end], fiber_lenghts[32:end-2], z_values[1:5:end, 32:end-2]', 
            ylabel="Fiber Lengths", xlabel="Time", zlabel="Temperature",
            title="Surface Plot of Temperature Spline Function", legend=false,
            xticks=(selected_ticks, selected_labels), size=(800,600) 
        )
        savefig(surfacepl, "surface_channel2_$(month_name)2024.html")
    
        contourpl = contourf(full_time_values[1:5:end], fiber_lenghts[32:end-2], z_values[1:5:end, 32:end-2]',  
            ylabel="Fiber Lengths", xlabel="Time", zlabel="Temperature",
            title="Contour Plot of Temperature Spline Function", legend=true,  color=:thermal, 
            xticks=(selected_ticks, selected_labels), size=(800,600) 
        )
        savefig(contourpl, "contour_channel2_$(month_name)2024.html")
    
        heatmappl = heatmap(full_time_values[1:5:end], fiber_lenghts[32:end-2], z_values[1:5:end, 32:end-2]',  
            ylabel="Fiber Lengths", xlabel="Time", zlabel="Temperature",
            title="Heatmap of Temperature Spline Function", legend=true,
            xticks=(selected_ticks, selected_labels), size=(800,600) 
        )
        savefig(heatmappl, "heatmap_channel2_$(month_name)2024.html")

        # Compute errors
        mean_absolute_error, max_absolute_error = compute_error_metrics(smooth_matrix, time_values, fiber_lengths, spline_2d)
        errors = Dict(
            "mean_absolute_error" => mean_absolute_error,
            "residuals_sum" => spline_2d.fp,
            "max_absolute_error" => max_absolute_error
        )

        # Save errors to JSON
        open("errors_channel2_$(month_name)2024.json", "w") do io
            JSON.print(io, errors)
        end

        # Derivative of temperature
        derivative_matrix = derivative(spline_2d, time_values, fiber_lengths, 1, 0)
        derivative_df = DataFrame(derivative_matrix, :auto)
        CSV.write("channel2_$(month_name)2024_derivative_matrix.csv", derivative_df)

        println("Month $(month_name) processing complete.")
    end
end

process_monthly_data(df_sorted, fiber_lengths, process_noise, measurement_noise, A, 20000)